#ifndef USER_APP_H
#define USER_APP_H

#include "types.h"

TASK tarefa_1(void);
TASK tarefa_2(void);
TASK tarefa_3(void);

void user_config(void);

#endif /* USER_APP_H */
