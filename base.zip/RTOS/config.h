#ifndef CONFIG_H
#define CONFIG_H

#define ON 1
#define OFF 0

#define MAX_USER_TASKS 3
#define MAX_STACK_SIZE 32

#define DEFAULT_SCHEDULER RR_SCHEDULER

#define IDLE_DEBUG ON
#define DYNAMIC_MEM OFF
#define PIPE_SIZE 3

// Aplicações exemplo
// Somente das tarefas
#define APP_1 ON

// Tarefa que utilizam semáforos
#define APP_2 OFF

// Tarefa que utiliza pipe
#define APP_3 OFF

#endif /* CONFIG_H */
